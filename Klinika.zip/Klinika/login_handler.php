<?php
session_start();
require 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Central Care</title>
    <link rel="stylesheet" href="public/css/hospital.css">
    <script src="https://kit.fontawesome.com/f30fac2c61.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <nav>
            <div class="logo">
                <h1>Central Care</h1>
            </div>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#service">Services</a></li>
                <li><a href="#doctors">Doctors</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="#appointment">Appointment</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="dashboard.php">Личный кабинет</a></li>
                    <li><a href="logout.php">Выйти</a></li>
                <?php else: ?>
                    <li><a href="login.php">Вход</a></li>
                    <li><a href="register.php">Регистрация</a></li>
                <?php endif; ?>
            </ul>
            <i id="bar" class="fa-solid fa-bars"></i>
        </nav>

        <div class="main">
            <img src="public/img/main.png" alt="">
            <div class="mainText">
                <h1>Care With Best Centrall Care</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam, explicabo laboriosam temporibus delectus obcaecati repudiandae at quo, nihil animi fuga distinctio perspiciatis.</p>
                <button>Learn More</button>
            </div>
        </div>

        <div id="service">
            <div class="head">
                <h1>Our Services</h1>
            </div>
            <div class="service">
                <div class="serviceCard">
                    <img src="public/img/chest.webp" alt="">
                    <p>Chest and Respiratory</p>
                </div>
                <div class="serviceCard">
                    <img src="public/img/laboratory.webp" alt="">
                    <p>Laboratory</p>
                </div>
                <div class="serviceCard">
                    <img src="public/img/physio.webp" alt="">
                    <p>Physiotherapy</p>
                </div>
                <div class="serviceCard">
                    <img src="public/img/nutrition.webp" alt="">
                    <p>Nutrition</p>
                </div>
            </div>
        </div>
        <div id="doctors">
            <div class="head">
                <h1>Our Doctors</h1>
            </div>
            <div class="doctors">
                <?php
                $stmt = $pdo->query("SELECT id, name, photo FROM users WHERE role = 'doctor'");
                while ($doctor = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                    <div class="team" onclick='showDoctorInfo(<?php echo json_encode($doctor); ?>)'>
                        <?php if (!empty($doctor['photo'])): ?>
                            <img src="data:image/jpeg;base64,<?php echo $doctor['photo']; ?>" alt="<?php echo htmlspecialchars($doctor['name']); ?>">
                        <?php else: ?>
                            <img src="public/img/default-doctor.jpg" alt="Default Doctor">
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        <div id="blog">
            <div class="head">
                <h1>Read Blog</h1>
            </div>
            <div class="blogs">
                <div class="blogCard">
                    <img src="public/img/bl1.jfif" alt="">
                    <h2>Health Care</h2>
                    <a href="https://www.maxhealthcare.in/blogs">Read More</a>
                </div>
                <div class="blogCard">
                    <img src="public/img/bl2.jpg" alt="">
                    <h2>Health Care</h2>
                    <a href="https://www.maxhealthcare.in/blogs">Read More</a>
                </div>
                <div class="blogCard">
                    <img src="public/img/bl3.webp" alt="">
                    <h2>Health Care</h2>
                    <a href="https://www.maxhealthcare.in/blogs">Read More</a>
                </div>
            </div>
        </div>
        <div id="appointment">
            <div class="head">
                <h1>Book An Appointment</h1>
            </div>
            <div class="form">
                <input type="text" placeholder="Enter Name">
                <input type="text" placeholder="Enter Number">
                <input type="date">
                <input type="time">
                <button>Submit</button>
            </div>
        </div>

        <div class="footer">
            <div class="text">
                <h2>About</h2>
                <p>Lorem ipsum dolor sit amet conset <br>
                    adipisicing elit. Atque sed, optio <br>
                    eos maxime id obcaecati officia nes <br>
                    aut illum fugiat cum porro?</p>
            </div>
            <div class="text">
                <h2>Care</h2>
                <p>Facility</p>
                <p>Reviews</p>
                <p>Support</p>
                <p>Staff</p>
            </div>
            <div class="text">
                <h2>Address</h2>
                <p>JK Hills</p>
                <p>Galaxy Park</p>
                <p>220-9990</p>
                <p>maps on</p>
            </div>
            <div class="text">
                <h2>Connect Us</h2>
                <p>LinkedIn</p>
                <p>YouTube</p>
                <p>Facebook</p>
                <p>Instagram</p>
            </div>
        </div>
    </div>

    <div id="doctor-info-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeDoctorInfo()">&times;</span>
            <img id="doctor-modal-image" src="" alt="Doctor Image">
            <h3 id="doctor-modal-name"></h3>
            <p id="doctor-modal-info"></p>
        </div>
    </div>

    <script src="scripts.js"></script>
</body>
</html>
