function showDoctorInfo(doctor) {
    document.getElementById('doctor-modal-image').src = 'data:image/jpeg;base64,' + doctor.photo;
    document.getElementById('doctor-modal-name').textContent = doctor.name;
    document.getElementById('doctor-modal-info').textContent = 'Общая информация о враче...'; // Здесь вы можете добавить дополнительную информацию

    document.getElementById('doctor-info-modal').style.display = 'block';
}

function closeDoctorInfo() {
    document.getElementById('doctor-info-modal').style.display = 'none';
}
