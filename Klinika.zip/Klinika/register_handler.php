<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    // Обработка загрузки фотографии
    $photo = null;
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $photo = file_get_contents($_FILES['photo']['tmp_name']);
        $photo = base64_encode($photo); // Преобразование данных в base64
    }

    // Вставка данных в базу данных
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, photo) VALUES (?, ?, ?, ?, ?)");
    if ($stmt->execute([$name, $email, $password, $role, $photo])) {
        header("Location: login.php");
    } else {
        echo "Ошибка регистрации.";
    }
}
?>
