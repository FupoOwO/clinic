<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    // Обработка загрузки фотографии
    $photo = null;
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $photo = file_get_contents($_FILES['photo']['tmp_name']);
        $photo = base64_encode($photo); // Преобразование данных в base64
    }

    // Вставка данных в базу данных
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, photo) VALUES (?, ?, ?, ?, ?)");
    if ($stmt->execute([$name, $email, $password, $role, $photo])) {
        header("Location: login.php");
    } else {
        echo "Ошибка регистрации.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <h2>Регистрация</h2>
    <form action="register.php" method="POST" enctype="multipart/form-data">
        <label for="name">Имя:</label>
        <input type="text" id="name" name="name" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>
        <label for="role">Роль:</label>
        <select id="role" name="role">
            <option value="patient">Пациент</option>
            <option value="doctor">Врач</option>
        </select>
        <label for="photo">Фотография:</label>
        <input type="file" id="photo" name="photo" accept="image/*">
        <button type="submit">Зарегистрироваться</button>
    </form>
</body>
</html>
