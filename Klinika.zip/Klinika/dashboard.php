<?php
require 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$user_name = $_SESSION['user_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="dash.css">
</head>
<body>
    <h2>Личный кабинет</h2>
    <p>Добро пожаловать, <?php echo htmlspecialchars($user_name); ?>!</p>

    <?php if ($user_role == 'patient'): ?>
        <h3>Ваши записи на прием</h3>
        <ul>
            <?php
            $stmt = $pdo->prepare("SELECT u.name AS doctor_name, a.date, a.time FROM appointments a JOIN users u ON a.doctor_id = u.id WHERE a.patient_id = ?");
            $stmt->execute([$user_id]);
            while ($appointment = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<li>Врач: " . htmlspecialchars($appointment['doctor_name']) . " - Дата: " . htmlspecialchars($appointment['date']) . " - Время: " . htmlspecialchars($appointment['time']) . "</li>";
            }
            ?>
        </ul>

        <h3>Записаться на прием</h3>
        <form action="appointment_handler.php" method="POST">
            <label for="doctor">Выберите врача:</label>
            <select id="doctor" name="doctor">
                <?php
                $stmt = $pdo->query("SELECT * FROM users WHERE role = 'doctor'");
                while ($doctor = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<option value=\"" . htmlspecialchars($doctor['id']) . "\">" . htmlspecialchars($doctor['name']) . "</option>";
                }
                ?>
            </select>
            <label for="date">Дата:</label>
            <input type="date" id="date" name="date" required>
            <label for="time">Время:</label>
            <input type="time" id="time" name="time" required>
            <button type="submit">Записаться</button>
        </form>
    <?php elseif ($user_role == 'doctor'): ?>
        <h3>Ваши пациенты</h3>
        <ul>
            <?php
            $stmt = $pdo->prepare("SELECT u.name AS patient_name, a.date, a.time FROM appointments a JOIN users u ON a.patient_id = u.id WHERE a.doctor_id = ?");
            $stmt->execute([$user_id]);
            while ($appointment = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<li>Пациент: " . htmlspecialchars($appointment['patient_name']) . " - Дата: " . htmlspecialchars($appointment['date']) . " - Время: " . htmlspecialchars($appointment['time']) . "</li>";
            }
            ?>
        </ul>
    <?php endif; ?>
    <a href="index.php">На главную</a>
</body>
</html>
