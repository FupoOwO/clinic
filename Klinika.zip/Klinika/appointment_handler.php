<?php
require 'config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_id = $_SESSION['user_id'];
    $doctor_id = $_POST['doctor'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $stmt = $pdo->prepare("INSERT INTO appointments (patient_id, doctor_id, date, time) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$patient_id, $doctor_id, $date, $time])) {
        header("Location: dashboard.php");
    } else {
        echo "Ошибка записи на прием.";
    }
}
?>
